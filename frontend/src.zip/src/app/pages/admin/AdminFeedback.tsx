import { Building2, Star, TrendingUp } from "lucide-react";
import { mockFeedback } from "../../data/mockData";

export default function AdminFeedback() {
  const averageRating = (
    mockFeedback.reduce((sum, f) => sum + f.rating, 0) / mockFeedback.length
  ).toFixed(1);

  const ratingDistribution = [5, 4, 3, 2, 1].map((rating) => ({
    rating,
    count: mockFeedback.filter((f) => f.rating === rating).length,
  }));

  return (
    <div className="flex-1">
      <header className="bg-white border-b border-gray-200 px-8 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Employee Feedback</h1>
            <p className="text-gray-600 mt-1">View ratings and comments from resolved tickets</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-br from-blue-600 to-blue-700 p-2 rounded-lg">
              <Building2 className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
      </header>

      <main className="p-8">
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Overall Satisfaction</h2>
            <div className="flex items-center gap-4 mb-6">
              <div className="text-6xl font-bold text-blue-600">{averageRating}</div>
              <div>
                <div className="flex gap-1 mb-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`w-6 h-6 ${
                        star <= Math.round(parseFloat(averageRating))
                          ? "fill-yellow-400 text-yellow-400"
                          : "text-gray-300"
                      }`}
                    />
                  ))}
                </div>
                <div className="text-sm text-gray-600">
                  Based on {mockFeedback.length} reviews
                </div>
              </div>
            </div>

            <div className="space-y-3">
              {ratingDistribution.map((item) => (
                <div key={item.rating} className="flex items-center gap-3">
                  <div className="flex gap-1 w-24">
                    {[...Array(item.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <div className="flex-1 bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full"
                      style={{
                        width: `${(item.count / mockFeedback.length) * 100}%`,
                      }}
                    ></div>
                  </div>
                  <div className="text-sm text-gray-600 w-12 text-right">{item.count}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Key Metrics</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                <div>
                  <div className="text-sm text-gray-600 mb-1">Positive Feedback</div>
                  <div className="text-2xl font-bold text-green-600">
                    {Math.round(
                      (mockFeedback.filter((f) => f.rating >= 4).length / mockFeedback.length) *
                        100
                    )}
                    %
                  </div>
                </div>
                <TrendingUp className="w-8 h-8 text-green-600" />
              </div>

              <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                <div>
                  <div className="text-sm text-gray-600 mb-1">Total Reviews</div>
                  <div className="text-2xl font-bold text-blue-600">{mockFeedback.length}</div>
                </div>
                <Star className="w-8 h-8 text-blue-600" />
              </div>

              <div className="flex items-center justify-between p-4 bg-purple-50 rounded-lg">
                <div>
                  <div className="text-sm text-gray-600 mb-1">Response Rate</div>
                  <div className="text-2xl font-bold text-purple-600">87%</div>
                </div>
                <TrendingUp className="w-8 h-8 text-purple-600" />
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Recent Feedback</h2>
          <div className="space-y-4">
            {mockFeedback.map((feedback) => (
              <div key={feedback.id} className="border border-gray-200 rounded-lg p-6">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="font-semibold text-gray-900 mb-1">{feedback.employeeName}</div>
                    <div className="text-sm text-gray-600">Ticket: {feedback.ticketId}</div>
                  </div>
                  <div className="text-right">
                    <div className="flex gap-1 mb-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`w-5 h-5 ${
                            star <= feedback.rating
                              ? "fill-yellow-400 text-yellow-400"
                              : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                    <div className="text-sm text-gray-500">
                      {new Date(feedback.date).toLocaleDateString()}
                    </div>
                  </div>
                </div>
                <div className="text-gray-700 bg-gray-50 p-4 rounded-lg">
                  "{feedback.comment}"
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
