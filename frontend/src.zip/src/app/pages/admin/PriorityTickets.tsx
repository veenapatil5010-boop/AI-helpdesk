import { Building2, AlertTriangle } from "lucide-react";
import { mockTickets } from "../../data/mockData";

export default function PriorityTickets() {
  const highPriorityTickets = mockTickets.filter((t) => t.priority === "High");

  return (
    <div className="flex-1">
      <header className="bg-white border-b border-gray-200 px-8 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Priority Tickets</h1>
            <p className="text-gray-600 mt-1">High priority tickets requiring immediate attention</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-br from-blue-600 to-blue-700 p-2 rounded-lg">
              <Building2 className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
      </header>

      <main className="p-8">
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-6 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
          <div>
            <div className="font-semibold text-red-900 mb-1">Critical Attention Required</div>
            <div className="text-sm text-red-700">
              {highPriorityTickets.length} high priority tickets require immediate action from support teams.
            </div>
          </div>
        </div>

        <div className="grid gap-6">
          {highPriorityTickets.map((ticket) => (
            <div key={ticket.id} className="bg-white rounded-xl shadow-sm border-l-4 border-red-500 p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-semibold text-gray-900">{ticket.id}</h3>
                    <span className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-xs font-medium">
                      High Priority
                    </span>
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        ticket.status === "Resolved"
                          ? "bg-green-100 text-green-700"
                          : ticket.status === "In Progress"
                          ? "bg-blue-100 text-blue-700"
                          : "bg-orange-100 text-orange-700"
                      }`}
                    >
                      {ticket.status}
                    </span>
                  </div>
                  <div className="text-sm text-gray-600">{ticket.category}</div>
                </div>
                <div className="text-right">
                  <div className="text-sm text-gray-600 mb-1">Created</div>
                  <div className="font-medium text-gray-900">
                    {new Date(ticket.createdDate).toLocaleDateString()}
                  </div>
                </div>
              </div>

              <div className="mb-4">
                <div className="text-sm font-medium text-gray-700 mb-2">Issue Description</div>
                <div className="text-gray-600">{ticket.description}</div>
              </div>

              <div className="grid md:grid-cols-4 gap-4 mb-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="text-sm text-gray-600 mb-1">Employee</div>
                  <div className="font-medium text-gray-900">{ticket.employeeName}</div>
                  <div className="text-xs text-gray-500">{ticket.employeeId}</div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="text-sm text-gray-600 mb-1">Department</div>
                  <div className="font-medium text-gray-900">{ticket.department}</div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="text-sm text-gray-600 mb-1">Assigned To</div>
                  <div className="font-medium text-gray-900">{ticket.assignedTo || "Unassigned"}</div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="text-sm text-gray-600 mb-1">Est. Resolution</div>
                  <div className="font-medium text-red-600">1-2 hours</div>
                </div>
              </div>

              <div className="flex gap-3">
                <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                  Assign to Team
                </button>
                <button className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                  View Details
                </button>
                <button className="px-4 py-2 border border-green-600 text-green-600 rounded-lg hover:bg-green-50 transition-colors">
                  Mark Resolved
                </button>
              </div>
            </div>
          ))}

          {highPriorityTickets.length === 0 && (
            <div className="bg-white rounded-xl shadow-sm p-12 text-center">
              <AlertTriangle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                No high priority tickets
              </h3>
              <p className="text-gray-600">All high priority tickets have been addressed</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
