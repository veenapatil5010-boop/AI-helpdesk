import { Outlet } from "react-router";
import { Sidebar } from "../../components/Sidebar";
import {
  LayoutDashboard,
  Ticket,
  AlertCircle,
  Building2 as BuildingIcon,
  MessageSquare,
  LogOut,
} from "lucide-react";

const adminLinks = [
  { to: "/admin", icon: LayoutDashboard, label: "Dashboard" },
  { to: "/admin/new-tickets", icon: Ticket, label: "New Tickets" },
  { to: "/admin/priority-tickets", icon: AlertCircle, label: "Priority Tickets" },
  { to: "/admin/department-tickets", icon: BuildingIcon, label: "Department Tickets" },
  { to: "/admin/feedback", icon: MessageSquare, label: "Feedback" },
  { to: "/", icon: LogOut, label: "Logout" },
];

export default function AdminDashboard() {
  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar links={adminLinks} />
      <Outlet />
    </div>
  );
}
