import { Outlet } from "react-router";
import { Sidebar } from "../../components/Sidebar";
import {
  LayoutDashboard,
  PlusCircle,
  Ticket,
  Clock,
  MessageSquare,
  User,
  LogOut,
} from "lucide-react";

const userLinks = [
  { to: "/user", icon: LayoutDashboard, label: "Dashboard" },
  { to: "/user/create-ticket", icon: PlusCircle, label: "Create Ticket" },
  { to: "/user/my-tickets", icon: Ticket, label: "My Tickets" },
  { to: "/user/processing", icon: Clock, label: "Processing Tickets" },
  { to: "/user/feedback", icon: MessageSquare, label: "Feedback" },
  { to: "/user/profile", icon: User, label: "Profile" },
  { to: "/", icon: LogOut, label: "Logout" },
];

export default function UserDashboard() {
  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar links={userLinks} />
      <Outlet />
    </div>
  );
}
