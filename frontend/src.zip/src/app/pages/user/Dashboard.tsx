import { Link } from "react-router";
import {
  LayoutDashboard,
  PlusCircle,
  Ticket,
  Clock,
  MessageSquare,
  User,
  LogOut,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Building2,
} from "lucide-react";
import { mockTickets } from "../../data/mockData";

export default function Dashboard() {
  const userTickets = mockTickets.filter((t) => t.employeeId === "EMP-1234");
  const totalTickets = userTickets.length;
  const openTickets = userTickets.filter((t) => t.status === "Open").length;
  const inProgressTickets = userTickets.filter((t) => t.status === "In Progress").length;
  const resolvedTickets = userTickets.filter((t) => t.status === "Resolved").length;

  return (
    <div className="flex-1">
      <header className="bg-white border-b border-gray-200 px-8 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Employee Dashboard</h1>
            <p className="text-gray-600 mt-1">Welcome back, Rajesh Kumar</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-br from-blue-600 to-blue-700 p-2 rounded-lg">
              <Building2 className="w-6 h-6 text-white" />
            </div>
            <div className="text-right">
              <div className="font-semibold text-gray-900">JSW Steel</div>
              <div className="text-sm text-gray-600">Production Dept.</div>
            </div>
          </div>
        </div>
      </header>

      <main className="p-8">
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-blue-100 p-3 rounded-lg">
                <Ticket className="w-6 h-6 text-blue-600" />
              </div>
              <TrendingUp className="w-5 h-5 text-gray-400" />
            </div>
            <div className="text-2xl font-bold text-gray-900 mb-1">{totalTickets}</div>
            <div className="text-sm text-gray-600">Total Tickets</div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-orange-100 p-3 rounded-lg">
                <AlertCircle className="w-6 h-6 text-orange-600" />
              </div>
            </div>
            <div className="text-2xl font-bold text-gray-900 mb-1">{openTickets}</div>
            <div className="text-sm text-gray-600">Open Tickets</div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-blue-100 p-3 rounded-lg">
                <Clock className="w-6 h-6 text-blue-600" />
              </div>
            </div>
            <div className="text-2xl font-bold text-gray-900 mb-1">{inProgressTickets}</div>
            <div className="text-sm text-gray-600">In Progress</div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-green-100 p-3 rounded-lg">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
            </div>
            <div className="text-2xl font-bold text-gray-900 mb-1">{resolvedTickets}</div>
            <div className="text-sm text-gray-600">Resolved</div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h2>
          <div className="grid md:grid-cols-3 gap-4">
            <Link
              to="/user/create-ticket"
              className="flex items-center gap-3 p-4 border-2 border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all group"
            >
              <div className="bg-blue-100 p-3 rounded-lg group-hover:bg-blue-200 transition">
                <PlusCircle className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <div className="font-semibold text-gray-900">Create New Ticket</div>
                <div className="text-sm text-gray-600">Raise a support request</div>
              </div>
            </Link>

            <Link
              to="/user/my-tickets"
              className="flex items-center gap-3 p-4 border-2 border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all group"
            >
              <div className="bg-purple-100 p-3 rounded-lg group-hover:bg-purple-200 transition">
                <Ticket className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <div className="font-semibold text-gray-900">View My Tickets</div>
                <div className="text-sm text-gray-600">Track your requests</div>
              </div>
            </Link>

            <Link
              to="/user/feedback"
              className="flex items-center gap-3 p-4 border-2 border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all group"
            >
              <div className="bg-green-100 p-3 rounded-lg group-hover:bg-green-200 transition">
                <MessageSquare className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <div className="font-semibold text-gray-900">Submit Feedback</div>
                <div className="text-sm text-gray-600">Rate your experience</div>
              </div>
            </Link>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Recent Tickets</h2>
            <Link to="/user/my-tickets" className="text-sm text-blue-600 hover:text-blue-700">
              View All
            </Link>
          </div>
          <div className="space-y-3">
            {userTickets.slice(0, 3).map((ticket) => (
              <div key={ticket.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <div className="font-medium text-gray-900">{ticket.id}</div>
                  <div className="text-sm text-gray-600">{ticket.category}</div>
                </div>
                <div className="text-right">
                  <div
                    className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${
                      ticket.status === "Resolved"
                        ? "bg-green-100 text-green-700"
                        : ticket.status === "In Progress"
                        ? "bg-blue-100 text-blue-700"
                        : "bg-orange-100 text-orange-700"
                    }`}
                  >
                    {ticket.status}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
