import { useState } from "react";
import { useNavigate } from "react-router";
import { Sidebar } from "../../components/Sidebar";
import {
  LayoutDashboard,
  PlusCircle,
  Ticket,
  Clock,
  MessageSquare,
  User,
  LogOut,
  Building2,
  Upload,
  Sparkles,
} from "lucide-react";

const userLinks = [
  { to: "/user", icon: LayoutDashboard, label: "Dashboard" },
  { to: "/user/create-ticket", icon: PlusCircle, label: "Create Ticket" },
  { to: "/user/my-tickets", icon: Ticket, label: "My Tickets" },
  { to: "/user/processing", icon: Clock, label: "Processing Tickets" },
  { to: "/user/feedback", icon: MessageSquare, label: "Feedback" },
  { to: "/user/profile", icon: User, label: "Profile" },
  { to: "/", icon: LogOut, label: "Logout" },
];

export default function CreateTicket() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    employeeName: "Rajesh Kumar",
    department: "",
    category: "",
    description: "",
    attachment: null as File | null,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock submission
    alert("Ticket created successfully! AI has automatically prioritized your ticket.");
    navigate("/user/my-tickets");
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar links={userLinks} />
      
      <div className="flex-1">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Create New Ticket</h1>
              <p className="text-gray-600 mt-1">Submit your support request</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-blue-600 to-blue-700 p-2 rounded-lg">
                <Building2 className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="p-8">
          <div className="max-w-3xl mx-auto">
            {/* AI Notice */}
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-xl p-4 mb-6 flex items-start gap-3">
              <Sparkles className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
              <div>
                <div className="font-semibold text-blue-900 mb-1">AI-Powered Ticket Management</div>
                <div className="text-sm text-blue-700">
                  Our AI will automatically predict ticket priority, route to the correct department, 
                  and estimate resolution time based on your input.
                </div>
              </div>
            </div>

            {/* Form */}
            <div className="bg-white rounded-xl shadow-sm p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Employee Name */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Employee Name
                  </label>
                  <input
                    type="text"
                    value={formData.employeeName}
                    onChange={(e) => setFormData({ ...formData, employeeName: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                    required
                  />
                </div>

                {/* Department */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Department
                  </label>
                  <select
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                    required
                  >
                    <option value="">Select department</option>
                    <option value="Production">Production</option>
                    <option value="IT">IT</option>
                    <option value="HR">HR</option>
                    <option value="SAP">SAP</option>
                    <option value="Logistics">Logistics</option>
                    <option value="Finance">Finance</option>
                  </select>
                </div>

                {/* Category */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Issue Category
                  </label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                    required
                  >
                    <option value="">Select category</option>
                    <option value="IT Support">IT Support</option>
                    <option value="System Access">System Access</option>
                    <option value="Equipment Issue">Equipment Issue</option>
                    <option value="HR Query">HR Query</option>
                    <option value="SAP Issue">SAP Issue</option>
                    <option value="Network Issue">Network Issue</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                {/* Problem Description */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Problem Description
                  </label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    rows={6}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none resize-none"
                    placeholder="Please describe your issue in detail..."
                    required
                  />
                </div>

                {/* File Attachment */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Attachment (Optional)
                  </label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-500 transition-colors">
                    <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                    <div className="text-sm text-gray-600 mb-2">
                      Click to upload or drag and drop
                    </div>
                    <div className="text-xs text-gray-500">
                      PNG, JPG, PDF up to 10MB
                    </div>
                    <input
                      type="file"
                      onChange={(e) => setFormData({ ...formData, attachment: e.target.files?.[0] || null })}
                      className="hidden"
                      accept=".png,.jpg,.jpeg,.pdf"
                    />
                  </div>
                </div>

                {/* Submit Button */}
                <div className="flex gap-4 pt-4">
                  <button
                    type="submit"
                    className="flex-1 bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors shadow-sm"
                  >
                    Submit Ticket
                  </button>
                  <button
                    type="button"
                    onClick={() => navigate("/user")}
                    className="px-8 py-3 border border-gray-300 rounded-lg font-semibold text-gray-700 hover:bg-gray-50 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
