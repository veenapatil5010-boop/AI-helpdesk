import { useState } from "react";
import { Sidebar } from "../../components/Sidebar";
import {
  LayoutDashboard,
  PlusCircle,
  Ticket,
  Clock,
  MessageSquare,
  User,
  LogOut,
  Building2,
  Star,
  CheckCircle,
} from "lucide-react";
import { mockTickets } from "../../data/mockData";

const userLinks = [
  { to: "/user", icon: LayoutDashboard, label: "Dashboard" },
  { to: "/user/create-ticket", icon: PlusCircle, label: "Create Ticket" },
  { to: "/user/my-tickets", icon: Ticket, label: "My Tickets" },
  { to: "/user/processing", icon: Clock, label: "Processing Tickets" },
  { to: "/user/feedback", icon: MessageSquare, label: "Feedback" },
  { to: "/user/profile", icon: User, label: "Profile" },
  { to: "/", icon: LogOut, label: "Logout" },
];

export default function UserFeedback() {
  const resolvedTickets = mockTickets.filter(
    (t) => t.employeeId === "EMP-1234" && t.status === "Resolved"
  );

  const [feedbackData, setFeedbackData] = useState<{
    [key: string]: { rating: number; comment: string };
  }>({});

  const [submittedTickets, setSubmittedTickets] = useState<Set<string>>(new Set());

  const handleRating = (ticketId: string, rating: number) => {
    setFeedbackData({
      ...feedbackData,
      [ticketId]: { ...feedbackData[ticketId], rating },
    });
  };

  const handleComment = (ticketId: string, comment: string) => {
    setFeedbackData({
      ...feedbackData,
      [ticketId]: { ...feedbackData[ticketId], comment },
    });
  };

  const handleSubmit = (ticketId: string) => {
    const feedback = feedbackData[ticketId];
    if (feedback && feedback.rating) {
      setSubmittedTickets(new Set([...submittedTickets, ticketId]));
      alert("Thank you for your feedback!");
    } else {
      alert("Please provide a rating before submitting.");
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar links={userLinks} />

      <div className="flex-1">
        <header className="bg-white border-b border-gray-200 px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Feedback</h1>
              <p className="text-gray-600 mt-1">Rate your resolved tickets</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-blue-600 to-blue-700 p-2 rounded-lg">
                <Building2 className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>
        </header>

        <main className="p-8">
          {resolvedTickets.length > 0 ? (
            <div className="grid gap-6">
              {resolvedTickets.map((ticket) => (
                <div key={ticket.id} className="bg-white rounded-xl shadow-sm p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-lg font-semibold text-gray-900">{ticket.id}</h3>
                        <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                          Resolved
                        </span>
                      </div>
                      <div className="text-sm text-gray-600 mb-1">{ticket.category}</div>
                      <div className="text-gray-700">{ticket.description}</div>
                    </div>
                  </div>

                  {submittedTickets.has(ticket.id) ? (
                    <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <div>
                        <div className="font-medium text-green-900">Feedback Submitted</div>
                        <div className="text-sm text-green-700">
                          Thank you for rating this ticket!
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="border-t border-gray-200 pt-4 mt-4">
                      <div className="mb-4">
                        <label className="block text-sm font-medium text-gray-700 mb-3">
                          Rate your experience
                        </label>
                        <div className="flex gap-2">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <button
                              key={star}
                              onClick={() => handleRating(ticket.id, star)}
                              className="focus:outline-none transition-transform hover:scale-110"
                            >
                              <Star
                                className={`w-8 h-8 ${
                                  feedbackData[ticket.id]?.rating >= star
                                    ? "fill-yellow-400 text-yellow-400"
                                    : "text-gray-300"
                                }`}
                              />
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="mb-4">
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Additional Comments (Optional)
                        </label>
                        <textarea
                          value={feedbackData[ticket.id]?.comment || ""}
                          onChange={(e) => handleComment(ticket.id, e.target.value)}
                          rows={3}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none resize-none"
                          placeholder="Share your thoughts about the support you received..."
                        />
                      </div>

                      <button
                        onClick={() => handleSubmit(ticket.id)}
                        className="bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors"
                      >
                        Submit Feedback
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-xl shadow-sm p-12 text-center">
              <MessageSquare className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                No resolved tickets to rate
              </h3>
              <p className="text-gray-600">
                Once your tickets are resolved, you can provide feedback here
              </p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
